 const Remove =(id)=>{

    return{
        type:'REMOVE',
        payload:id
    };

};
export default Remove;