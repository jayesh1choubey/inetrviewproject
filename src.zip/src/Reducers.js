// import {combineReducer} from 'redux';
// import Objreducer from './Objreducer';

// const rootReducer = combineReducer({
//     post:Objreducer
// });

// export default rootReducer;